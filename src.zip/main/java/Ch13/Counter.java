package Ch13;

public class Counter {
	private int count; //0초기화

	public int getCount() {
		return count;
	}

	public void setCount() {
		this.count++;
	}
	
}
