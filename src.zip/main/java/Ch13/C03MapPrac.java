package Ch13;

public class C03MapPrac {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
//사용자 계정과 사용자의 프로필정보를 저장하는
//MAP 객체를 만들고 확인합니다(3명의 정보 받아보기)
//
//Map<String,Profile> map = new Hashmap();
//
//[출력 예]
//계정 입력 : jwg1234
//사용자 이름 : 정우균
//사용자 주소 : 대구
//사용자 연락처 : 010-111-2222
//...
//계정명 : jwg1234
//이름 : 정우균
//주소 : 대구
//연락처 : 010-111-2222
